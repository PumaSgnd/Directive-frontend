import React from 'react';

const BlankPage: React.FC = () => {
  return (
    <div>
      <h1>Page Not Available</h1>
      <p>This page is under construction.</p>
    </div>
  );
};

export default BlankPage;
