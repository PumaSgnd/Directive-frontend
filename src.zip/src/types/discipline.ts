export interface Discipline {
    id: number;
    discipline: string;
    abbreviation: string;
    gender: string;
}
